Please download the data from https://github.com/ee16b/eigenfaces-data/archive/0fd01ccb0660d2b98669718aa2d36f49d4019934.zip
